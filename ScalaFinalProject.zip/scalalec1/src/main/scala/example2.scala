import scala.io.StdIn._

object example2 extends App
{
  println("Enter the two numbers:")
  val number1 = readInt()
  val number2 = readInt()

  println(number2,number1)
 println(s"$number2  $number1")


}
