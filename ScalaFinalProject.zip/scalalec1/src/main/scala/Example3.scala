import scala.io.StdIn._

object example3 extends App
{
  println("Please enter the first number:")
  val number1 = readInt()
  println("Please enter the second number:")
  val number2 = readInt()
  println("Please enter the third number:")
  val number3 = readInt()

  if (number1 >= 0 && number2 >= 0 && number3 >= 0) {
    var largest = 0

    if (number2 >= largest && number2 >= number3) {
      largest = number2
    }
    else if(number3>=number2 && number3>=number1)
        {
          largest = number3
        }
    else
      largest = number1

    println(s"The largest number is $largest")
  }
    else
      println("Sorry you must enter a positive number")

  }
