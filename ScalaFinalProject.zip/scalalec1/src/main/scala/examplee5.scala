import scala.io.StdIn._

object examplee5 extends App
{

  println("Please enter a positive integer:")
  val loopNumber = readInt()

  var sum = 0

  if (loopNumber > 0) {
    for (i <- 1 to loopNumber) {
      sum += i
    }

    println(s"The sum of numbers from 1 to $loopNumber is: $sum")
  } else {
    println("Please enter only positive integers")
  }



}
