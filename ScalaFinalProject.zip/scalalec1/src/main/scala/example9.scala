import scala.io.StdIn._
object example9 extends App{

  println("Please enter the size of  matrix:")
  val n = readInt()

  if (n > 0) {
    for (i <- 1 to n) {
      for (j <- 1 to n) {
        if (i == j) {
          print("1 ")
        } else {
          print("0 ")
        }
      }
      println()
    }
  } else {
    println("Please enter a positive integer")
  }

}
