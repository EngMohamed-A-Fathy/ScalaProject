import scala.io.StdIn._
object example7 extends App{

  println("Please enter a number:")
  val num = readInt()
  var total = ""
  if (num > 0) {
    println("The divisors of " + num + " are:")
    for (i <- 1 to num) {
      if (num % i == 0) {
        total = total + i + " "
      }
    }
    println(total)
  } else {
    println("Please enter a positive integer")
  }
}
