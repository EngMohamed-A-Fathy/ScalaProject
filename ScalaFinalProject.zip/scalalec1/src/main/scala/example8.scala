import scala.io.StdIn._
object example8 extends App{

  println("Please enter a number to check if it's prime or not:")
  val num = readInt()
  var check = true

  if (num < 0) {
    println("Please enter a positive number")
  }
  else if (num == 1) {
    println("no")
  }
  else if (num > 1) {
    check = true

    for (i <- 2 until num) {
      if (num % i == 0) {
        check = false
      }
    }
        if (check) {
          println("yes")
        } else {
          println("no")
        }
      }
  }






