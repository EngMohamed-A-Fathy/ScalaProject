
import scala.io.Source
import scala.io.StdIn._
import java.io.PrintWriter
import java.io.File

object Lab3Decrypt extends App {

  def addColumn(listOfLists: List[List[String]]): List[List[String]] = {
    listOfLists.map(row => row :+ "")
  }

  def renameColumn(listOfLists: List[List[String]], columnIndex: Int, newName: String): List[List[String]] = {
    listOfLists match {
      case head :: tail => (head.updated(columnIndex, newName) :: tail).map(_.toList)
    }}

  def updateList(listOfLists: List[List[String]]): List[List[String]] = {
    listOfLists.map {

      //      case list if(list(2).toInt>=12000000 && list(2).toInt < 13000000) => list.updated(4, "Orange")
      //      case list if(list(2).toInt>=11000000 && list(2).toInt < 12000000) => list.updated(4, "Etisalat")
      //      case list if(list(2).toInt>=15000000 && list(2).toInt < 16000000) => list.updated(4, "WE")
      case list if(list(2).take(2)=="12") => list.updated(4, "Orange")
      case list if(list(2).take(2)=="11") => list.updated(4, "Etisalat")
      case list if(list(2).take(2)=="15") => list.updated(4, "WE")
      case list if(list(2).take(2)=="b_") => list.updated(4,"Operator");



    }
  }

  def updateListFare(listOfLists: List[List[String]]): List[List[String]] = {
    listOfLists.map {
      case list if (list(4)=="Operator" ) => { list.updated(5, "Fare")}
      case list if (list(4)=="WE" ) => {
        val duration = list(3).split(":").map(_.toInt)
        val totalDuration = duration(0) * 3600 + duration(1) * 60 + duration(2)
        val fare = (totalDuration / 60 + 1) * 0.14
        list.updated(5, fare.toString)
      }
      case list if (list(4) == "Orange" || list(4)=="Etisalat") => {
        val duration = list(3).split(":").map(_.toInt)
        val totalDuration = duration(0) * 3600 + duration(1) * 60 + duration(2)
        val fare = (totalDuration / 60 + 1) * 0.15
        list.updated(5, fare.toString)
      }

    }
  }

  def DecryptCol2(listOfLists: List[List[String]]): List[List[String]] = {
    listOfLists.map {
      case list if (list(1).take(2) != "a_") => {
        val number2 = list(1)
        val decrypted = number2.toCharArray().map {
          case 'a' => '0'
          case '$' => '1'
          case '%' => '2'
          case '^' => '3'
          case '*' => '4'
          case 'f' => '5'
          case '[' => '6'
          case '(' => '7'
          case '@' => '8'
          case '/' => '9'
        }.mkString("")
        list.updated(1, decrypted.take(8))
      }
      case list if (list(2).take(2) == "b_") => list.updated(4, "Operator");
    }
  }
  def DecryptCol3(listOfLists: List[List[String]]): List[List[String]] = {
    listOfLists.map {
      case list if (list(2).take(2) != "b_") => {
        val number2 = list(2)
        val encrypted = number2.toCharArray().map {
          case 'a' => '0'
          case '$' => '1'
          case '%' => '2'
          case '^' => '3'
          case '*' => '4'
          case 'f' => '5'
          case '[' => '6'
          case '(' => '7'
          case '@' => '8'
          case '/' => '9'
        }.mkString("")
        list.updated(2, encrypted.take(8))
      }
      case list if(list(2).take(2)=="b_") => list.updated(4,"Operator");
    }
  }
  val filename = "E:/finallab.csv"
  val lines = Source.fromFile(filename).getLines.toList
  val listofLists = lines.map(line => line.split(",").toList)
//  val listWithNewColumn = addColumn(listofLists)
//  val renamedList = renameColumn(listWithNewColumn, 4, "Operator")
//  val Operaters = updateList(renamedList)
//  val addColumnForFare = addColumn(Operaters)
//  val Fare = updateListFare(addColumnForFare)
  val decrypting = DecryptCol3(listofLists)
  val decrypting2 = DecryptCol2(decrypting)

  val csvString = decrypting2.map(_.mkString(",")).mkString("\n")

  // Write the string to a file
  val writer = new PrintWriter("E:/finallab2.csv")
  writer.write(csvString)
  writer.close()

  print(decrypting2)

  //  print(test)

}