import scala.io.Source
import scala.math.ceil

//"D:\\iti\\Scala\\project\\Project\\TRX10.csv"

object F_Project extends App {

  val readFile: String => List[String] = link => {
    val file = Source.fromFile(link)
    val lines = file.getLines().drop(1).toList
    lines
  }

  case class Row(quantity: Int, channel: String, paymentMethod: String, unitPrice: Double)

  val getRow: String => Row = line => {
    val column = line.split(",")
    Row(
      quantity = column(3).toInt, channel = column(5), paymentMethod = column(6), unitPrice = column(4).toDouble)
  }

  // First One
  val isSaleThroughApp: String => Boolean = SalesChannel => {
    SalesChannel == "App"
  }

  val getDiscountPercentage: (Boolean, Int) => Double = (flag, quantity) => {
    flag match {
      case true => {
        if(quantity>0){
          val roundedQuantity = (ceil((quantity-1) / 5) + 1).toInt * .05
          roundedQuantity
        } else 0
      }
      case false =>
        0
    }
  }


  // Second One
  val isVisaCard: String => Boolean = PayMethod => {
    PayMethod == "Visa"
  }

  val getDiscountForVisa: Boolean => Double = flag => {
    flag match {
      case true => {
        val discount = .05
        discount
      }
      case false =>
        0
    }
  }


  // cal Final price
  val calFinalPrice: (Double,  Double ) => Double = (price,discount) => {
    if (discount > 0) price*(1- discount)  else price
  }


  // calling the functions
  val lines = readFile("D:\\iti\\Scala\\project\\Project\\TRX10.csv")
  val rows = lines.map(getRow)

  // first discount
  val discounts1 = rows.map(row => getDiscountPercentage(isSaleThroughApp(row.channel), row.quantity))
  println(discounts1)

  // second discount
  val discounts2 = rows.map(row => getDiscountForVisa(isVisaCard(row.paymentMethod)))
  println(discounts2)

  // adding final Price
  val unitPrice = rows.map(row => row.unitPrice)
  print(unitPrice.zip(discounts1).map{case(a,b)=> calFinalPrice(a,b)})

}
