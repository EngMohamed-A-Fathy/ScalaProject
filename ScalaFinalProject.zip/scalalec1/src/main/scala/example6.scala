import scala.io.StdIn._
object example6 extends App{

  println("Please enter a positive power :")
  val num = readInt()

  var power = 0
  var total = ""
  if (num > 0) {
    for (i <- 0 to  num) {
      power = math.pow(2,i).toInt
      total = total + power + " "
    }

    println(s"The power of numbers from 1 to $num is: $total")
  } else {
    println("Please enter only positive integers")
  }
}
