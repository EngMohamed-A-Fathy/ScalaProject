import scala.io.StdIn._

object example4 extends App {


  println("Please enter your score:")
  val score = readDouble()

  if (score > 0 && score < 100) {
    if (score >= 85 && score <= 100) {
      println("Excellent A")
    } else if (score >= 75 && score <= 84) {
      println("Very Good B")
    } else if (score >= 65 && score <= 74) {
      println("Good C")
    } else if (score >= 50 && score <= 64) {
      println("Pass D")
    } else {
      println("Failed F")
    }
  }else{
    println("Please number a positive number between 0 and 100")
  }




}
