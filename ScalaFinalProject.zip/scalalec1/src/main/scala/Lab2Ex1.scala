import scala.io.StdIn._
import scala.io.Source
object Lab2Ex1 extends App {
  val filename = "E:/students.txt"
  val lines = Source.fromFile(filename).getLines.toList
  val listofLists = lines.map(line => line.split("\\W+").map(_.trim).toList)
  val rangeofid = listofLists.map(_.head).map(_.toInt)
//  val num = ""
  var check = true
  println("Welcome in our database")
  try {
    while (check) {
      println("please enter the ID you want")
      val num = readLine()
      if (num == "q") {
        check = false
      }
      else if (rangeofid.contains(num.toInt)) {
        val matchingName = listofLists.filter(sublist => sublist.head == num).map(sublist => sublist(1))
        val matchingAge = listofLists.filter(sublist => sublist.head == num).map(sublist => sublist(2))
        var name = matchingName(0)
        var age = matchingAge(0)

        println(s"Hello, The name you are looking for is $name and his age is $age")
        println("Thanks for using data base , press q to exit if you want!")

      } else {
        println("Sorry the ID you entered isn't inside our database")
      }
    }
    println("Good bye, thanks for using our database!")
  }catch {
    case _: NumberFormatException =>
      println("Sorry, that's not a valid ID. Please enter a number or q to exit.")
  }
}
//  println (matchingName)
//  println (matchingAge)




