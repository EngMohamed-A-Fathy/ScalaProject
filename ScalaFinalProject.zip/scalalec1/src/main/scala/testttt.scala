import Project.calFinalPrice

import java.io.PrintWriter
import java.time.format.{DateTimeFormatter, DateTimeParseException}
import java.time.temporal.ChronoUnit
import java.time.{Instant, LocalDate, LocalDateTime, ZoneOffset}
import scala.io.Source
import scala.math.ceil

object Project2 extends App {

  def check3(list: List[String]): Boolean = {
    val item = list(1).split(" ")
    if (item(0).toUpperCase == "WINE" || item(0).toUpperCase == "CHEESE") {
      true
    } else false
  }

  def dis3(list: List[String]): Double = {
    val item = list(1).split("-")
    item(0).toUpperCase match {
      case "WINE " => 0.05
      case "CHEESE " => 0.10
      case _ => 0.0
    }
  }

  def check4(list: List[String]): Boolean = {
    val timestamp = Instant.parse(list(0)).atOffset(ZoneOffset.UTC).toLocalDate
    val formatter = DateTimeFormatter.ofPattern("M/d/yyyy")
    val expiry = try {
      LocalDate.parse(list(2), formatter)
    } catch {
      case _: DateTimeParseException =>
        val formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        LocalDate.parse(list(2), formatter2)
    }
    ChronoUnit.DAYS.between(timestamp, expiry) <= 30
  }

  def dis4(list: List[String]): Double = {
    val timestamp = Instant.parse(list(0)).atOffset(ZoneOffset.UTC).toLocalDate
    val formatter = DateTimeFormatter.ofPattern("M/d/yyyy")
    val expiry = try {
      LocalDate.parse(list(2), formatter)
    } catch {
      case _: DateTimeParseException =>
        val formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        LocalDate.parse(list(2), formatter2)
    }

    val daysLeft = ChronoUnit.DAYS.between(timestamp, expiry)
    (30 - daysLeft) * 0.01
  }


  val filename = "E:/scalaproject/TRX1000.csv"
  val lines = Source.fromFile(filename).getLines.toList
  val listofLists = lines.map(_.split(",").toList)

  case class DiscountRule(check: List[String] => Boolean, applyDiscount: List[String] => Double)

  val discountRules = List(
    DiscountRule(check3, dis3),
    DiscountRule(check4, dis4)
  )
  val calFinalPrice: (Double, Double) => Double = (price, discount) => {
    if (discount > 0) price * (1 - discount) else price
  }

  def applyDiscount(list: List[String], businessRules: List[DiscountRule]): Double = {
    val successfulRules = businessRules.filter(dataRow => dataRow.check(list))
    successfulRules match {
      case Nil => 0.0
      case List(dataRow) => dataRow.applyDiscount(list)
      case _ =>
        val top2Rules = successfulRules.sortBy(dataRow => dataRow.applyDiscount(list)).takeRight(2)
        (top2Rules(0).applyDiscount(list) + top2Rules(1).applyDiscount(list)) / 2.0
    }
  }

  val header = listofLists.head :+ "discount" :+ "final price"
  val orders = listofLists.tail
  val discountedOrders = orders.map { order =>
    val discount = applyDiscount(order, discountRules)
    val finalPrice = calFinalPrice(order(4).toDouble, discount)
    order :+ discount.toString :+ finalPrice
  }

  val output = (header :: discountedOrders).map(_.mkString(",")).mkString("\n")
  println(output)

  val writer = new PrintWriter("E:/scalaproject/TRX10_discounted.csv")
  writer.write(output)
  writer.close()
}