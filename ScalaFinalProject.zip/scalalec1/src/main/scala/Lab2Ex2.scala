import scala.io.Source
import scala.io.StdIn._

object Lab2Ex2 extends App {
  val filename = "E:/wordcount.txt"
  val lines = Source.fromFile(filename).getLines.toList
  val words = lines.flatMap(line => line.split("\\W+").map(_.trim).toList)
  val groups = words.groupBy(identity)
  val mapvalues = groups.mapValues(_.map(_ => 1)).toMap
  val reducing = mapvalues.mapValues(_.reduce(_ + _)).toMap
  println(reducing)
}